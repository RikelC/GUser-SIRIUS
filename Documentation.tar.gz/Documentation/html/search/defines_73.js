var searchData=
[
  ['sampling_5fperiod',['sampling_period',['../global_8h.html#aa97f500326cad565e777556be7636177',1,'global.h']]]
];
