var searchData=
[
  ['n',['N',['../classtunnelMacroPixel.html#ace0b247e6a94c8d82de4fc0c0fad1887',1,'tunnelMacroPixel::N()'],['../classtunnelPixel.html#a0101ecddd1bf069572cfc2f08e74fc52',1,'tunnelPixel::N()']]],
  ['name',['name',['../classtunnelMacroPixel.html#a7c0ba8abdf0b8bca0fad37349c061dba',1,'tunnelMacroPixel']]],
  ['nboards_5fdssd',['NBOARDS_DSSD',['../classmyGlobal.html#a399a2e00f97753fddfd6da6b75b4d954',1,'myGlobal']]],
  ['nboards_5ftunnel',['NBOARDS_TUNNEL',['../classmyGlobal.html#a4202c241d15c15f12aad63986dc661c8',1,'myGlobal']]],
  ['ndetector_5ftunnel',['NDETECTOR_TUNNEL',['../classmyGlobal.html#a10306574fb426584758e649296a07047',1,'myGlobal']]],
  ['nend_5ftrace',['nEnd_trace',['../classmyGlobal.html#a5c17a6b60640e3806b760cc3f6fff17e',1,'myGlobal']]],
  ['nofmacropixels',['NofMacroPixels',['../classmyGlobal.html#aa2ea7ece2b6205e077816cca5c6ba030',1,'myGlobal']]],
  ['noise',['Noise',['../classdssdData.html#a7db8f25b9096dca214030b471505a6ed',1,'dssdData']]],
  ['noisy_5fsignal',['noisy_signal',['../classdssdData.html#a37bdf1c2dafcd4c7c4a91a7565b73f25',1,'dssdData']]],
  ['nstart_5ftrace',['nStart_trace',['../classmyGlobal.html#aac85e17b925cff314e8d42121a2c10be',1,'myGlobal']]],
  ['nstrips_5fdssd',['NSTRIPS_DSSD',['../classmyGlobal.html#a9313ad0d818dbc6a9cdb85a5bdc7cdbe',1,'myGlobal']]]
];
