var searchData=
[
  ['myglobaldestroyer',['myGlobalDestroyer',['../classmyGlobal.html#a29ea12f360d27547d209506d74cdbf45',1,'myGlobal']]]
];
