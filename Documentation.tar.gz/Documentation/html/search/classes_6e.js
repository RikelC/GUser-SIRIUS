var searchData=
[
  ['numexo2data',['numexo2Data',['../classnumexo2Data.html',1,'']]]
];
