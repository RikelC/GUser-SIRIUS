var searchData=
[
  ['x',['X',['../classdssdPixel.html#a038226478fd07aebec53650a89a92484',1,'dssdPixel::X()'],['../classtunnelPixel.html#aafaefe57851ea012fe5df721b0806ecf',1,'tunnelPixel::X()']]]
];
