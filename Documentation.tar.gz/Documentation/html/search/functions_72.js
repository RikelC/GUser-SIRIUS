var searchData=
[
  ['readrunconfig',['readRunConfig',['../classmyGlobal.html#a549633c7d2368b955021a0e3966e6d94',1,'myGlobal']]],
  ['remove_5fextra_5fspaces',['remove_extra_spaces',['../global_8cc.html#afa959a9bb3ea03b5a0c8db600e77edaf',1,'global.cc']]]
];
