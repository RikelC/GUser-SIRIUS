var searchData=
[
  ['g_5finstance',['g_instance',['../classGUser.html#ac6f9fa695bddc87721669b29dfb433ce',1,'GUser']]],
  ['gain',['gain',['../classGUser.html#a70789bf4a8552bba577d9257c9664df5',1,'GUser::gain()'],['../classdssdData.html#acf943f6a5bf0fdc19bebd1e5b397655e',1,'dssdData::gain()']]],
  ['gain_5fswitch_5fflag',['gain_switch_flag',['../classdssdData.html#a0be6a48ef8f45db598add840b2ecbc94',1,'dssdData']]],
  ['gamma_5fcalib_5ffilename',['gamma_calib_filename',['../classmyGlobal.html#a8630ff3c8ea82b216ade88afd8d730a0',1,'myGlobal']]],
  ['gr_5fbaseline',['gr_baseline',['../classGUser.html#ad4aaadd40bd4b57a9c6348d252f3206c',1,'GUser']]],
  ['gr_5frate_5fdssdboard',['gr_rate_dssdBoard',['../classGUser.html#a698db5b22361f07e44a88ad79513d57b',1,'GUser']]],
  ['gr_5frate_5ftunnelboard',['gr_rate_tunnelBoard',['../classGUser.html#adb4cfdd1b5c2342175d07bb64f91adb8',1,'GUser']]]
];
