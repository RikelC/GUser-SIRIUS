var searchData=
[
  ['gedata',['geData',['../classgeData.html',1,'']]],
  ['guser',['GUser',['../classGUser.html',1,'']]]
];
