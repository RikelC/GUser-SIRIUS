var searchData=
[
  ['kpar',['kPar',['../classdigitalFilters.html#a529e1b092b8913faecfddd87e43032b7',1,'digitalFilters']]]
];
