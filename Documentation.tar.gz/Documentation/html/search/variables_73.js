var searchData=
[
  ['s1',['s1',['../classGUser.html#a0a4c629c981353ac6e92a90f1e9f4018',1,'GUser::s1()'],['../classcalibration.html#ad0a19c2abbf4e07bf9933389d86b523b',1,'calibration::s1()'],['../classdigitalCFD.html#a0db71c860f029ab6a51216af5b7004f0',1,'digitalCFD::s1()'],['../classdigitalFilters.html#a9055afde183e0e401871c4b8b47dd0ed',1,'digitalFilters::s1()'],['../classdssdEvent.html#a6f71246cf60499813dd2bf5166e0f002',1,'dssdEvent::s1()'],['../classnumexo2Data.html#a5d2ffa5888b613a1dbf23d67e4195f92',1,'numexo2Data::s1()'],['../classtrackerData.html#a5939398dd8d1054fba64fbb5689d8cb1',1,'trackerData::s1()']]],
  ['saturated',['saturated',['../classdssdData.html#af858b6f3ad9354fb1b6ac9ae9bb8f8b4',1,'dssdData']]],
  ['saturationtime',['SaturationTime',['../classdssdData.html#aeeda910ae7e2547290b075f2d4b65c08',1,'dssdData']]],
  ['saturationtime_5fthreshold',['saturationTime_threshold',['../classmyGlobal.html#a2e250f7ed401ce98fd193da339a9d7fd',1,'myGlobal']]],
  ['shaperamplificationgain',['shaperAmplificationGain',['../classmyGlobal.html#a9cbf78edebba4c9a970380b5beeddc5e',1,'myGlobal']]],
  ['signal_5fis',['signal_is',['../classdssdData.html#ad95ac94102eafb26b532b3650c22d348',1,'dssdData']]],
  ['signalheight',['signalHeight',['../classdssdData.html#a0515b494f9a5917a137be08d8dca106c',1,'dssdData']]],
  ['skip_5fnsamples_5fcalcul_5fhg',['skip_nSamples_calcul_HG',['../classmyGlobal.html#a92be39ba8e6b2345937719c798d0b1f3',1,'myGlobal']]],
  ['skip_5fnsamples_5fcalcul_5flg',['skip_nSamples_calcul_LG',['../classmyGlobal.html#a946fa64f5dc9fcaf00569a8bdd022a0f',1,'myGlobal']]],
  ['start_5fnew_5fevent',['start_new_event',['../classdssdEvent.html#a77621b782b51ab2d5d8d6c3ca7037e8d',1,'dssdEvent']]],
  ['strip',['strip',['../classdssdDataPoint.html#adab543aea760223766fbf7a160c47d26',1,'dssdDataPoint']]],
  ['stripmap',['stripMap',['../classdssdData.html#a8b1b8f44947f90d5a3267aa4ba2225e0',1,'dssdData']]],
  ['stripnumber',['stripnumber',['../classGUser.html#ac8d8c2fa1cd95715b2ac54c31b778f56',1,'GUser::stripnumber()'],['../classdssdData.html#afa43de78937bec3036cdfd6322a67474',1,'dssdData::stripnumber()']]],
  ['sum_5fneighboring_5fstrips',['sum_neighboring_strips',['../classmyGlobal.html#a2dcf0fe5c0fff0067212e8a7d37257e5',1,'myGlobal']]]
];
