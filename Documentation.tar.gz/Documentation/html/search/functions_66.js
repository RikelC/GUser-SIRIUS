var searchData=
[
  ['from_5fdssd',['from_dssd',['../classmyGlobal.html#a80bd80f0748da01ba20e2c09106da946',1,'myGlobal']]],
  ['from_5ftunnel',['from_tunnel',['../classmyGlobal.html#a8f5a86895f2cda9f22ae67ea2c1c2189',1,'myGlobal']]]
];
