var searchData=
[
  ['iboard',['iboard',['../classGUser.html#a4f7b276bc486f0ec7c27a1bfc8da06f9',1,'GUser']]],
  ['inflection_5fpoint',['inflection_point',['../classdssdData.html#adb4671f438f25f47428afbb2670671f1',1,'dssdData']]],
  ['initttreeuser',['InitTTreeUser',['../classGUser.html#af8394e81da5b731d62a359390df0334a',1,'GUser']]],
  ['inituser',['InitUser',['../classGUser.html#a7b087f21501b5f1c11355b6786b32ec5',1,'GUser']]],
  ['inituserrun',['InitUserRun',['../classGUser.html#adab35d8464a2ae31bb2fc32ae867abaf',1,'GUser']]],
  ['instance',['instance',['../classmyGlobal.html#a8a0341886780ea52791bb20d53e7d244',1,'myGlobal']]],
  ['interpolationtype',['InterpolationType',['../classmyGlobal.html#ad2e9cbdcfa045af46ba983cfde7972f2',1,'myGlobal']]],
  ['is_5fa_5fnew_5frun',['is_a_new_run',['../GruScript_8C.html#a4efffbb612efeaf69d3e354094245560',1,'GruScript.C']]],
  ['is_5fbackstrip',['is_backStrip',['../classdssdDataPoint.html#a34dfe418cdc233b8befeff81964544f7',1,'dssdDataPoint']]],
  ['is_5ffrontstrip',['is_frontStrip',['../classdssdDataPoint.html#a074f5bb7362b65cf95e9cdb77fca4514',1,'dssdDataPoint']]],
  ['is_5fneighboringstripof',['is_neighboringStripOf',['../classdssdDataPoint.html#aefd8ccd508f51905cc6f45bf59e3148b',1,'dssdDataPoint']]],
  ['isemptyline',['isEmptyLine',['../global_8cc.html#a4c46e0f70f9d6693b15e9251937efdfe',1,'global.cc']]],
  ['it_5fis_5fnoisy',['it_is_noisy',['../classdssdData.html#ab890584710303620a89a10046388b1da',1,'dssdData']]],
  ['it_5fis_5fsaturated',['it_is_saturated',['../classdssdData.html#ae711a704d0f5515d4e442166eb0c9837',1,'dssdData']]]
];
