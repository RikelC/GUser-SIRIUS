var searchData=
[
  ['iboard',['iboard',['../classGUser.html#a4f7b276bc486f0ec7c27a1bfc8da06f9',1,'GUser']]],
  ['inflection_5fpoint',['inflection_point',['../classdssdData.html#adb4671f438f25f47428afbb2670671f1',1,'dssdData']]],
  ['instance',['instance',['../classmyGlobal.html#a8a0341886780ea52791bb20d53e7d244',1,'myGlobal']]],
  ['interpolationtype',['InterpolationType',['../classmyGlobal.html#ad2e9cbdcfa045af46ba983cfde7972f2',1,'myGlobal']]]
];
