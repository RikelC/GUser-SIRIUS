var searchData=
[
  ['rand',['rand',['../classcalibration.html#ab3a54aa506347cbe9f9fb1f7173974a2',1,'calibration']]],
  ['rate_5fcalcul_5ftime_5flapse',['rate_calcul_time_lapse',['../classmyGlobal.html#af2c94386b1f29b1729926a88c897db7b',1,'myGlobal']]],
  ['rate_5fcalcul_5ftimestamp_5flapse',['rate_calcul_timestamp_lapse',['../classGUser.html#af3308b111530772a92dc4bb607fa3e84',1,'GUser']]],
  ['rate_5fcounter_5fdssd',['rate_counter_dssd',['../classGUser.html#a1a277ca2b578f897c4c8b2b23bb6dd56',1,'GUser']]],
  ['rate_5fcounter_5ftunnel',['rate_counter_tunnel',['../classGUser.html#a296a1f002cfec53c12a0a9965e91b9d6',1,'GUser']]],
  ['rate_5fcounterpoint_5fdssd',['rate_counterPoint_dssd',['../classGUser.html#aa6e277d0acb5bd19a618cc6547155a04',1,'GUser']]],
  ['rate_5fcounterpoint_5ftunnel',['rate_counterPoint_tunnel',['../classGUser.html#a8e1e48ebfe40829a95e7aa7a5c60e555',1,'GUser']]],
  ['raw_5fenergy',['raw_energy',['../classnumexo2Data.html#afcb321bab6aa7e6a63ec405eecd5f617',1,'numexo2Data']]],
  ['rc_5fconstant',['RC_constant',['../classdigitalFilters.html#a758c08fb047af053ac8a9cd720b1bb0e',1,'digitalFilters::RC_constant()'],['../classdssdData.html#a3113e49c8a1e767354618f77aa982850',1,'dssdData::RC_constant()']]],
  ['rectangular',['Rectangular',['../classdigitalFilters.html#ab9b329a96ebc4958bf4cce6a927e8886',1,'digitalFilters']]],
  ['reflection_5fpoint',['reflection_point',['../classdssdData.html#a360f7902190e49b58911929f4b2bc6b7',1,'dssdData']]],
  ['risetime',['RiseTime',['../classdssdData.html#ab14a1068d06e85e780de6eae0d879ced',1,'dssdData']]],
  ['risetime_5fdef',['riseTime_def',['../classmyGlobal.html#a9d1766eb4aabb15f3e5337c5aa6ca90a',1,'myGlobal']]]
];
