var searchData=
[
  ['resistance',['Resistance',['../global_8h.html#ad6323ca0201652db1f9c208ea2a36978',1,'global.h']]]
];
