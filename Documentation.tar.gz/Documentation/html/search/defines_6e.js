var searchData=
[
  ['nchannels',['NCHANNELS',['../global_8h.html#a691d7b16670ff882b13a000bd691adbe',1,'global.h']]]
];
