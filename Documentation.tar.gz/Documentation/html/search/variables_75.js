var searchData=
[
  ['use_5fdefault_5fcfd_5fparameters',['use_default_CFD_parameters',['../classmyGlobal.html#a742f2f8a678cfc4a3a19c2200dbda239',1,'myGlobal']]],
  ['use_5fdefault_5ffilter_5fparameters',['use_default_filter_parameters',['../classmyGlobal.html#a73719b7acbbaec4d87f422d0f6132c13',1,'myGlobal']]],
  ['use_5fdefault_5ffpcsa_5fgain',['use_default_FPCSA_Gain',['../classmyGlobal.html#a7907de40e6d7921da3dd9a5cf2fe04f7',1,'myGlobal']]]
];
