var searchData=
[
  ['schar',['schar',['../UTypes_8h.html#a0fd9ce9d735064461bebfe6037026093',1,'UTypes.h']]]
];
