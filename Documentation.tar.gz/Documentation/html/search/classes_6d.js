var searchData=
[
  ['myglobal',['myGlobal',['../classmyGlobal.html',1,'']]],
  ['myglobaldestroyer',['myGlobalDestroyer',['../classmyGlobalDestroyer.html',1,'']]]
];
