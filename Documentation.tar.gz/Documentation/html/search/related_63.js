var searchData=
[
  ['compareenergy',['compareEnergy',['../classdssdDataPoint.html#a53097346f2adeadfd7efd8f251da5163',1,'dssdDataPoint']]],
  ['comparetime',['compareTime',['../classdssdDataPoint.html#a151ebcb8adc4c4fa658180a46a7ac266',1,'dssdDataPoint']]]
];
