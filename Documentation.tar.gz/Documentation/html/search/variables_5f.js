var searchData=
[
  ['_5fg',['_g',['../classmyGlobalDestroyer.html#a7a6ce834c51707898c5e055a50ac4461',1,'myGlobalDestroyer']]]
];
